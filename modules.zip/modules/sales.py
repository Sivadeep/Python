print "Sales Application"
def create_cus(name, address):
	print "create customer"
def pur_process():
	print "get the customer and product info"
	print "do delivery"
	print "create an invoice"
	print "get money fropm the customer"
create_cus("cust1","ad1")
pur_process()
