import config
#import pur
from config import username
from pur import pur_process
print "ERP application..."
print "user name=",username
print "pasword=",config.password



