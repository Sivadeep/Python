
def fun():
	print "This is fun in f1"
def main():
	print "this is f1"
	print "__name__",__name__
	fun()
if __name__ == "__main__":
	main()