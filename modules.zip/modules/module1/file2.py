print "file2"
def fun():
	print "this is fun in file2"
def main():
	pass
if __name__ == "__main__":
	main()