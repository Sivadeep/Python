print "Purchase Application"
def create_sup(name, address):
	print "create supplier"
	print "supplier creation done."
def pur_process():
	create_sup("sup1","ad1")
	print "get the supplier and product info"
	print "do delivery"
	print "create an invoice"
	print "send money to suplier"

pur_process()
